﻿/**
 * @file         main.cs
 * @author	     Darren Morrison
 * @date         2022-09-27
 * @brief        User Interface Assignment 3
 * @details      Used to start order system.
 */

OrderSystem system = new OrderSystem();