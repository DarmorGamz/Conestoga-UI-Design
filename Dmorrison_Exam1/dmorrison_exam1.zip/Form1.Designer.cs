﻿namespace dmorrison_Exam1 {
    partial class PlaneSeatReservation {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if(disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PlaneSeatReservation));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnF1 = new System.Windows.Forms.Button();
            this.btnF2 = new System.Windows.Forms.Button();
            this.btnF3 = new System.Windows.Forms.Button();
            this.btnE3 = new System.Windows.Forms.Button();
            this.btnE2 = new System.Windows.Forms.Button();
            this.btnE1 = new System.Windows.Forms.Button();
            this.btnA3 = new System.Windows.Forms.Button();
            this.btnA2 = new System.Windows.Forms.Button();
            this.btnA1 = new System.Windows.Forms.Button();
            this.btnB3 = new System.Windows.Forms.Button();
            this.btnB2 = new System.Windows.Forms.Button();
            this.btnB1 = new System.Windows.Forms.Button();
            this.btnC3 = new System.Windows.Forms.Button();
            this.btnC2 = new System.Windows.Forms.Button();
            this.btnC1 = new System.Windows.Forms.Button();
            this.btnD3 = new System.Windows.Forms.Button();
            this.btnD2 = new System.Windows.Forms.Button();
            this.btnD1 = new System.Windows.Forms.Button();
            this.btnF12 = new System.Windows.Forms.Button();
            this.btnF11 = new System.Windows.Forms.Button();
            this.btnF10 = new System.Windows.Forms.Button();
            this.btnF15 = new System.Windows.Forms.Button();
            this.btnF14 = new System.Windows.Forms.Button();
            this.btnF13 = new System.Windows.Forms.Button();
            this.btnF18 = new System.Windows.Forms.Button();
            this.btnF17 = new System.Windows.Forms.Button();
            this.btnF16 = new System.Windows.Forms.Button();
            this.btnE18 = new System.Windows.Forms.Button();
            this.btnE17 = new System.Windows.Forms.Button();
            this.btnE16 = new System.Windows.Forms.Button();
            this.btnE15 = new System.Windows.Forms.Button();
            this.btnE14 = new System.Windows.Forms.Button();
            this.btnE13 = new System.Windows.Forms.Button();
            this.btnE12 = new System.Windows.Forms.Button();
            this.btnE11 = new System.Windows.Forms.Button();
            this.btnE10 = new System.Windows.Forms.Button();
            this.btnA18 = new System.Windows.Forms.Button();
            this.btnA17 = new System.Windows.Forms.Button();
            this.btnA16 = new System.Windows.Forms.Button();
            this.btnA15 = new System.Windows.Forms.Button();
            this.btnA14 = new System.Windows.Forms.Button();
            this.btnA13 = new System.Windows.Forms.Button();
            this.btnA12 = new System.Windows.Forms.Button();
            this.btnA11 = new System.Windows.Forms.Button();
            this.btnA10 = new System.Windows.Forms.Button();
            this.btnB18 = new System.Windows.Forms.Button();
            this.btnB17 = new System.Windows.Forms.Button();
            this.btnB16 = new System.Windows.Forms.Button();
            this.btnB15 = new System.Windows.Forms.Button();
            this.btnB14 = new System.Windows.Forms.Button();
            this.btnB13 = new System.Windows.Forms.Button();
            this.btnB12 = new System.Windows.Forms.Button();
            this.btnB11 = new System.Windows.Forms.Button();
            this.btnB10 = new System.Windows.Forms.Button();
            this.btnGreen = new System.Windows.Forms.Button();
            this.btnRed = new System.Windows.Forms.Button();
            this.lblGreen = new System.Windows.Forms.Label();
            this.lblRed = new System.Windows.Forms.Label();
            this.btnBlue = new System.Windows.Forms.Button();
            this.lblBlue = new System.Windows.Forms.Label();
            this.tbxFirstName = new System.Windows.Forms.TextBox();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.tbxLastName = new System.Windows.Forms.TextBox();
            this.lblPostalCode = new System.Windows.Forms.Label();
            this.tbxPostalCode = new System.Windows.Forms.TextBox();
            this.btnReserveSeat = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lbxReserved = new System.Windows.Forms.ListBox();
            this.lblReserved = new System.Windows.Forms.Label();
            this.lblYellow = new System.Windows.Forms.Label();
            this.btnYellow = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnCancelSeat = new System.Windows.Forms.Button();
            this.err1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.err1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1241, 397);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnF1
            // 
            this.btnF1.BackColor = System.Drawing.Color.PaleGreen;
            this.btnF1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnF1.FlatAppearance.BorderSize = 0;
            this.btnF1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnF1.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnF1.Location = new System.Drawing.Point(136, 69);
            this.btnF1.Name = "btnF1";
            this.btnF1.Size = new System.Drawing.Size(29, 30);
            this.btnF1.TabIndex = 1;
            this.btnF1.Text = "F1";
            this.btnF1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnF1.UseVisualStyleBackColor = false;
            this.btnF1.Click += new System.EventHandler(this.buttonOnClick);
            this.btnF1.Enter += new System.EventHandler(this.buttonEnter);
            this.btnF1.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnF2
            // 
            this.btnF2.BackColor = System.Drawing.Color.PaleGreen;
            this.btnF2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnF2.FlatAppearance.BorderSize = 0;
            this.btnF2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnF2.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnF2.Location = new System.Drawing.Point(169, 69);
            this.btnF2.Name = "btnF2";
            this.btnF2.Size = new System.Drawing.Size(29, 30);
            this.btnF2.TabIndex = 2;
            this.btnF2.Text = "F2";
            this.btnF2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnF2.UseVisualStyleBackColor = false;
            this.btnF2.Click += new System.EventHandler(this.buttonOnClick);
            this.btnF2.Enter += new System.EventHandler(this.buttonEnter);
            this.btnF2.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnF3
            // 
            this.btnF3.BackColor = System.Drawing.Color.PaleGreen;
            this.btnF3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnF3.FlatAppearance.BorderSize = 0;
            this.btnF3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnF3.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnF3.Location = new System.Drawing.Point(202, 69);
            this.btnF3.Name = "btnF3";
            this.btnF3.Size = new System.Drawing.Size(29, 30);
            this.btnF3.TabIndex = 3;
            this.btnF3.Text = "F3";
            this.btnF3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnF3.UseVisualStyleBackColor = false;
            this.btnF3.Click += new System.EventHandler(this.buttonOnClick);
            this.btnF3.Enter += new System.EventHandler(this.buttonEnter);
            this.btnF3.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnE3
            // 
            this.btnE3.BackColor = System.Drawing.Color.PaleGreen;
            this.btnE3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnE3.FlatAppearance.BorderSize = 0;
            this.btnE3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnE3.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnE3.Location = new System.Drawing.Point(202, 105);
            this.btnE3.Name = "btnE3";
            this.btnE3.Size = new System.Drawing.Size(29, 30);
            this.btnE3.TabIndex = 15;
            this.btnE3.Text = "E3";
            this.btnE3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnE3.UseVisualStyleBackColor = false;
            this.btnE3.Click += new System.EventHandler(this.buttonOnClick);
            this.btnE3.Enter += new System.EventHandler(this.buttonEnter);
            this.btnE3.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnE2
            // 
            this.btnE2.BackColor = System.Drawing.Color.PaleGreen;
            this.btnE2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnE2.FlatAppearance.BorderSize = 0;
            this.btnE2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnE2.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnE2.Location = new System.Drawing.Point(169, 105);
            this.btnE2.Name = "btnE2";
            this.btnE2.Size = new System.Drawing.Size(29, 30);
            this.btnE2.TabIndex = 14;
            this.btnE2.Text = "E2";
            this.btnE2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnE2.UseVisualStyleBackColor = false;
            this.btnE2.Click += new System.EventHandler(this.buttonOnClick);
            this.btnE2.Enter += new System.EventHandler(this.buttonEnter);
            this.btnE2.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnE1
            // 
            this.btnE1.BackColor = System.Drawing.Color.PaleGreen;
            this.btnE1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnE1.FlatAppearance.BorderSize = 0;
            this.btnE1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnE1.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnE1.Location = new System.Drawing.Point(136, 105);
            this.btnE1.Name = "btnE1";
            this.btnE1.Size = new System.Drawing.Size(29, 30);
            this.btnE1.TabIndex = 13;
            this.btnE1.Text = "E1";
            this.btnE1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnE1.UseVisualStyleBackColor = false;
            this.btnE1.Click += new System.EventHandler(this.buttonOnClick);
            this.btnE1.Enter += new System.EventHandler(this.buttonEnter);
            this.btnE1.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnA3
            // 
            this.btnA3.BackColor = System.Drawing.Color.PaleGreen;
            this.btnA3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnA3.FlatAppearance.BorderSize = 0;
            this.btnA3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA3.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnA3.Location = new System.Drawing.Point(202, 296);
            this.btnA3.Name = "btnA3";
            this.btnA3.Size = new System.Drawing.Size(29, 30);
            this.btnA3.TabIndex = 45;
            this.btnA3.Text = "A3";
            this.btnA3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnA3.UseVisualStyleBackColor = false;
            this.btnA3.Click += new System.EventHandler(this.buttonOnClick);
            this.btnA3.Enter += new System.EventHandler(this.buttonEnter);
            this.btnA3.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnA2
            // 
            this.btnA2.BackColor = System.Drawing.Color.PaleGreen;
            this.btnA2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnA2.FlatAppearance.BorderSize = 0;
            this.btnA2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA2.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnA2.Location = new System.Drawing.Point(169, 296);
            this.btnA2.Name = "btnA2";
            this.btnA2.Size = new System.Drawing.Size(29, 30);
            this.btnA2.TabIndex = 44;
            this.btnA2.Text = "A2";
            this.btnA2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnA2.UseVisualStyleBackColor = false;
            this.btnA2.Click += new System.EventHandler(this.buttonOnClick);
            this.btnA2.Enter += new System.EventHandler(this.buttonEnter);
            this.btnA2.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnA1
            // 
            this.btnA1.BackColor = System.Drawing.Color.PaleGreen;
            this.btnA1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnA1.FlatAppearance.BorderSize = 0;
            this.btnA1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA1.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnA1.Location = new System.Drawing.Point(136, 296);
            this.btnA1.Name = "btnA1";
            this.btnA1.Size = new System.Drawing.Size(29, 30);
            this.btnA1.TabIndex = 43;
            this.btnA1.Text = "A1";
            this.btnA1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnA1.UseVisualStyleBackColor = false;
            this.btnA1.Click += new System.EventHandler(this.buttonOnClick);
            this.btnA1.Enter += new System.EventHandler(this.buttonEnter);
            this.btnA1.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnB3
            // 
            this.btnB3.BackColor = System.Drawing.Color.PaleGreen;
            this.btnB3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnB3.FlatAppearance.BorderSize = 0;
            this.btnB3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnB3.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnB3.Location = new System.Drawing.Point(202, 260);
            this.btnB3.Name = "btnB3";
            this.btnB3.Size = new System.Drawing.Size(29, 30);
            this.btnB3.TabIndex = 33;
            this.btnB3.Text = "B3";
            this.btnB3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnB3.UseVisualStyleBackColor = false;
            this.btnB3.Click += new System.EventHandler(this.buttonOnClick);
            this.btnB3.Enter += new System.EventHandler(this.buttonEnter);
            this.btnB3.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnB2
            // 
            this.btnB2.BackColor = System.Drawing.Color.PaleGreen;
            this.btnB2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnB2.FlatAppearance.BorderSize = 0;
            this.btnB2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnB2.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnB2.Location = new System.Drawing.Point(169, 260);
            this.btnB2.Name = "btnB2";
            this.btnB2.Size = new System.Drawing.Size(29, 30);
            this.btnB2.TabIndex = 32;
            this.btnB2.Text = "B2";
            this.btnB2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnB2.UseVisualStyleBackColor = false;
            this.btnB2.Click += new System.EventHandler(this.buttonOnClick);
            this.btnB2.Enter += new System.EventHandler(this.buttonEnter);
            this.btnB2.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnB1
            // 
            this.btnB1.BackColor = System.Drawing.Color.PaleGreen;
            this.btnB1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnB1.FlatAppearance.BorderSize = 0;
            this.btnB1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnB1.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnB1.Location = new System.Drawing.Point(136, 260);
            this.btnB1.Name = "btnB1";
            this.btnB1.Size = new System.Drawing.Size(29, 30);
            this.btnB1.TabIndex = 31;
            this.btnB1.Text = "B1";
            this.btnB1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnB1.UseVisualStyleBackColor = false;
            this.btnB1.Click += new System.EventHandler(this.buttonOnClick);
            this.btnB1.Enter += new System.EventHandler(this.buttonEnter);
            this.btnB1.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnC3
            // 
            this.btnC3.BackColor = System.Drawing.Color.PaleGreen;
            this.btnC3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnC3.FlatAppearance.BorderSize = 0;
            this.btnC3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnC3.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnC3.Location = new System.Drawing.Point(202, 201);
            this.btnC3.Name = "btnC3";
            this.btnC3.Size = new System.Drawing.Size(29, 30);
            this.btnC3.TabIndex = 30;
            this.btnC3.Text = "C3";
            this.btnC3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnC3.UseVisualStyleBackColor = false;
            this.btnC3.Click += new System.EventHandler(this.buttonOnClick);
            this.btnC3.Enter += new System.EventHandler(this.buttonEnter);
            this.btnC3.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnC2
            // 
            this.btnC2.BackColor = System.Drawing.Color.PaleGreen;
            this.btnC2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnC2.FlatAppearance.BorderSize = 0;
            this.btnC2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnC2.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnC2.Location = new System.Drawing.Point(169, 201);
            this.btnC2.Name = "btnC2";
            this.btnC2.Size = new System.Drawing.Size(29, 30);
            this.btnC2.TabIndex = 29;
            this.btnC2.Text = "C3";
            this.btnC2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnC2.UseVisualStyleBackColor = false;
            this.btnC2.Click += new System.EventHandler(this.buttonOnClick);
            this.btnC2.Enter += new System.EventHandler(this.buttonEnter);
            this.btnC2.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnC1
            // 
            this.btnC1.BackColor = System.Drawing.Color.PaleGreen;
            this.btnC1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnC1.FlatAppearance.BorderSize = 0;
            this.btnC1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnC1.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnC1.Location = new System.Drawing.Point(136, 201);
            this.btnC1.Name = "btnC1";
            this.btnC1.Size = new System.Drawing.Size(29, 30);
            this.btnC1.TabIndex = 28;
            this.btnC1.Text = "C1";
            this.btnC1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnC1.UseVisualStyleBackColor = false;
            this.btnC1.Click += new System.EventHandler(this.buttonOnClick);
            this.btnC1.Enter += new System.EventHandler(this.buttonEnter);
            this.btnC1.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnD3
            // 
            this.btnD3.BackColor = System.Drawing.Color.PaleGreen;
            this.btnD3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnD3.FlatAppearance.BorderSize = 0;
            this.btnD3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnD3.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnD3.Location = new System.Drawing.Point(202, 165);
            this.btnD3.Name = "btnD3";
            this.btnD3.Size = new System.Drawing.Size(29, 30);
            this.btnD3.TabIndex = 27;
            this.btnD3.Text = "D3";
            this.btnD3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnD3.UseVisualStyleBackColor = false;
            this.btnD3.Click += new System.EventHandler(this.buttonOnClick);
            this.btnD3.Enter += new System.EventHandler(this.buttonEnter);
            this.btnD3.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnD2
            // 
            this.btnD2.BackColor = System.Drawing.Color.PaleGreen;
            this.btnD2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnD2.FlatAppearance.BorderSize = 0;
            this.btnD2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnD2.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnD2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnD2.Location = new System.Drawing.Point(169, 165);
            this.btnD2.Name = "btnD2";
            this.btnD2.Size = new System.Drawing.Size(29, 30);
            this.btnD2.TabIndex = 26;
            this.btnD2.Text = "D2";
            this.btnD2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnD2.UseVisualStyleBackColor = false;
            this.btnD2.Click += new System.EventHandler(this.buttonOnClick);
            this.btnD2.Enter += new System.EventHandler(this.buttonEnter);
            this.btnD2.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnD1
            // 
            this.btnD1.BackColor = System.Drawing.Color.PaleGreen;
            this.btnD1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnD1.FlatAppearance.BorderSize = 0;
            this.btnD1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnD1.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnD1.Location = new System.Drawing.Point(136, 165);
            this.btnD1.Name = "btnD1";
            this.btnD1.Size = new System.Drawing.Size(29, 30);
            this.btnD1.TabIndex = 25;
            this.btnD1.Text = "D1";
            this.btnD1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnD1.UseVisualStyleBackColor = false;
            this.btnD1.Click += new System.EventHandler(this.buttonOnClick);
            this.btnD1.Enter += new System.EventHandler(this.buttonEnter);
            this.btnD1.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnF12
            // 
            this.btnF12.BackColor = System.Drawing.Color.PaleGreen;
            this.btnF12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnF12.FlatAppearance.BorderSize = 0;
            this.btnF12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnF12.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnF12.Location = new System.Drawing.Point(341, 69);
            this.btnF12.Name = "btnF12";
            this.btnF12.Size = new System.Drawing.Size(29, 30);
            this.btnF12.TabIndex = 6;
            this.btnF12.Text = "F2";
            this.btnF12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnF12.UseVisualStyleBackColor = false;
            this.btnF12.Click += new System.EventHandler(this.buttonOnClick);
            this.btnF12.Enter += new System.EventHandler(this.buttonEnter);
            this.btnF12.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnF11
            // 
            this.btnF11.BackColor = System.Drawing.Color.PaleGreen;
            this.btnF11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnF11.FlatAppearance.BorderSize = 0;
            this.btnF11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnF11.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnF11.Location = new System.Drawing.Point(310, 69);
            this.btnF11.Name = "btnF11";
            this.btnF11.Size = new System.Drawing.Size(29, 30);
            this.btnF11.TabIndex = 5;
            this.btnF11.Text = "F1";
            this.btnF11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnF11.UseVisualStyleBackColor = false;
            this.btnF11.Click += new System.EventHandler(this.buttonOnClick);
            this.btnF11.Enter += new System.EventHandler(this.buttonEnter);
            this.btnF11.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnF10
            // 
            this.btnF10.BackColor = System.Drawing.Color.PaleGreen;
            this.btnF10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnF10.FlatAppearance.BorderSize = 0;
            this.btnF10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnF10.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnF10.Location = new System.Drawing.Point(280, 69);
            this.btnF10.Name = "btnF10";
            this.btnF10.Size = new System.Drawing.Size(29, 30);
            this.btnF10.TabIndex = 4;
            this.btnF10.Text = "F0";
            this.btnF10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnF10.UseVisualStyleBackColor = false;
            this.btnF10.Click += new System.EventHandler(this.buttonOnClick);
            this.btnF10.Enter += new System.EventHandler(this.buttonEnter);
            this.btnF10.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnF15
            // 
            this.btnF15.BackColor = System.Drawing.Color.PaleGreen;
            this.btnF15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnF15.FlatAppearance.BorderSize = 0;
            this.btnF15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnF15.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnF15.Location = new System.Drawing.Point(431, 69);
            this.btnF15.Name = "btnF15";
            this.btnF15.Size = new System.Drawing.Size(29, 30);
            this.btnF15.TabIndex = 9;
            this.btnF15.Text = "F5";
            this.btnF15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnF15.UseVisualStyleBackColor = false;
            this.btnF15.Click += new System.EventHandler(this.buttonOnClick);
            this.btnF15.Enter += new System.EventHandler(this.buttonEnter);
            this.btnF15.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnF14
            // 
            this.btnF14.BackColor = System.Drawing.Color.PaleGreen;
            this.btnF14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnF14.FlatAppearance.BorderSize = 0;
            this.btnF14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnF14.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnF14.Location = new System.Drawing.Point(401, 69);
            this.btnF14.Name = "btnF14";
            this.btnF14.Size = new System.Drawing.Size(29, 30);
            this.btnF14.TabIndex = 8;
            this.btnF14.Text = "F4";
            this.btnF14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnF14.UseVisualStyleBackColor = false;
            this.btnF14.Click += new System.EventHandler(this.buttonOnClick);
            this.btnF14.Enter += new System.EventHandler(this.buttonEnter);
            this.btnF14.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnF13
            // 
            this.btnF13.BackColor = System.Drawing.Color.PaleGreen;
            this.btnF13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnF13.FlatAppearance.BorderSize = 0;
            this.btnF13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnF13.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnF13.Location = new System.Drawing.Point(371, 69);
            this.btnF13.Name = "btnF13";
            this.btnF13.Size = new System.Drawing.Size(29, 30);
            this.btnF13.TabIndex = 7;
            this.btnF13.Text = "F3";
            this.btnF13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnF13.UseVisualStyleBackColor = false;
            this.btnF13.Click += new System.EventHandler(this.buttonOnClick);
            this.btnF13.Enter += new System.EventHandler(this.buttonEnter);
            this.btnF13.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnF18
            // 
            this.btnF18.BackColor = System.Drawing.Color.PaleGreen;
            this.btnF18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnF18.FlatAppearance.BorderSize = 0;
            this.btnF18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnF18.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnF18.Location = new System.Drawing.Point(521, 69);
            this.btnF18.Name = "btnF18";
            this.btnF18.Size = new System.Drawing.Size(29, 30);
            this.btnF18.TabIndex = 12;
            this.btnF18.Text = "F8";
            this.btnF18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnF18.UseVisualStyleBackColor = false;
            this.btnF18.Click += new System.EventHandler(this.buttonOnClick);
            this.btnF18.Enter += new System.EventHandler(this.buttonEnter);
            this.btnF18.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnF17
            // 
            this.btnF17.BackColor = System.Drawing.Color.PaleGreen;
            this.btnF17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnF17.FlatAppearance.BorderSize = 0;
            this.btnF17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnF17.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnF17.Location = new System.Drawing.Point(491, 69);
            this.btnF17.Name = "btnF17";
            this.btnF17.Size = new System.Drawing.Size(29, 30);
            this.btnF17.TabIndex = 11;
            this.btnF17.Text = "F7";
            this.btnF17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnF17.UseVisualStyleBackColor = false;
            this.btnF17.Click += new System.EventHandler(this.buttonOnClick);
            this.btnF17.Enter += new System.EventHandler(this.buttonEnter);
            this.btnF17.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnF16
            // 
            this.btnF16.BackColor = System.Drawing.Color.PaleGreen;
            this.btnF16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnF16.FlatAppearance.BorderSize = 0;
            this.btnF16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnF16.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnF16.Location = new System.Drawing.Point(461, 69);
            this.btnF16.Name = "btnF16";
            this.btnF16.Size = new System.Drawing.Size(29, 30);
            this.btnF16.TabIndex = 10;
            this.btnF16.Text = "F6";
            this.btnF16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnF16.UseVisualStyleBackColor = false;
            this.btnF16.Click += new System.EventHandler(this.buttonOnClick);
            this.btnF16.Enter += new System.EventHandler(this.buttonEnter);
            this.btnF16.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnE18
            // 
            this.btnE18.BackColor = System.Drawing.Color.PaleGreen;
            this.btnE18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnE18.FlatAppearance.BorderSize = 0;
            this.btnE18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnE18.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnE18.Location = new System.Drawing.Point(521, 102);
            this.btnE18.Name = "btnE18";
            this.btnE18.Size = new System.Drawing.Size(29, 30);
            this.btnE18.TabIndex = 24;
            this.btnE18.Text = "E8";
            this.btnE18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnE18.UseVisualStyleBackColor = false;
            this.btnE18.Click += new System.EventHandler(this.buttonOnClick);
            this.btnE18.Enter += new System.EventHandler(this.buttonEnter);
            this.btnE18.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnE17
            // 
            this.btnE17.BackColor = System.Drawing.Color.PaleGreen;
            this.btnE17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnE17.FlatAppearance.BorderSize = 0;
            this.btnE17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnE17.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnE17.Location = new System.Drawing.Point(491, 102);
            this.btnE17.Name = "btnE17";
            this.btnE17.Size = new System.Drawing.Size(29, 30);
            this.btnE17.TabIndex = 23;
            this.btnE17.Text = "E7";
            this.btnE17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnE17.UseVisualStyleBackColor = false;
            this.btnE17.Click += new System.EventHandler(this.buttonOnClick);
            this.btnE17.Enter += new System.EventHandler(this.buttonEnter);
            this.btnE17.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnE16
            // 
            this.btnE16.BackColor = System.Drawing.Color.PaleGreen;
            this.btnE16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnE16.FlatAppearance.BorderSize = 0;
            this.btnE16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnE16.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnE16.Location = new System.Drawing.Point(461, 102);
            this.btnE16.Name = "btnE16";
            this.btnE16.Size = new System.Drawing.Size(29, 30);
            this.btnE16.TabIndex = 22;
            this.btnE16.Text = "E6";
            this.btnE16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnE16.UseVisualStyleBackColor = false;
            this.btnE16.Click += new System.EventHandler(this.buttonOnClick);
            this.btnE16.Enter += new System.EventHandler(this.buttonEnter);
            this.btnE16.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnE15
            // 
            this.btnE15.BackColor = System.Drawing.Color.PaleGreen;
            this.btnE15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnE15.FlatAppearance.BorderSize = 0;
            this.btnE15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnE15.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnE15.Location = new System.Drawing.Point(431, 102);
            this.btnE15.Name = "btnE15";
            this.btnE15.Size = new System.Drawing.Size(29, 30);
            this.btnE15.TabIndex = 21;
            this.btnE15.Text = "E5";
            this.btnE15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnE15.UseVisualStyleBackColor = false;
            this.btnE15.Click += new System.EventHandler(this.buttonOnClick);
            this.btnE15.Enter += new System.EventHandler(this.buttonEnter);
            this.btnE15.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnE14
            // 
            this.btnE14.BackColor = System.Drawing.Color.PaleGreen;
            this.btnE14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnE14.FlatAppearance.BorderSize = 0;
            this.btnE14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnE14.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnE14.Location = new System.Drawing.Point(401, 102);
            this.btnE14.Name = "btnE14";
            this.btnE14.Size = new System.Drawing.Size(29, 30);
            this.btnE14.TabIndex = 20;
            this.btnE14.Text = "E4";
            this.btnE14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnE14.UseVisualStyleBackColor = false;
            this.btnE14.Click += new System.EventHandler(this.buttonOnClick);
            this.btnE14.Enter += new System.EventHandler(this.buttonEnter);
            this.btnE14.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnE13
            // 
            this.btnE13.BackColor = System.Drawing.Color.PaleGreen;
            this.btnE13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnE13.FlatAppearance.BorderSize = 0;
            this.btnE13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnE13.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnE13.Location = new System.Drawing.Point(371, 102);
            this.btnE13.Name = "btnE13";
            this.btnE13.Size = new System.Drawing.Size(29, 30);
            this.btnE13.TabIndex = 19;
            this.btnE13.Text = "E3";
            this.btnE13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnE13.UseVisualStyleBackColor = false;
            this.btnE13.Click += new System.EventHandler(this.buttonOnClick);
            this.btnE13.Enter += new System.EventHandler(this.buttonEnter);
            this.btnE13.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnE12
            // 
            this.btnE12.BackColor = System.Drawing.Color.PaleGreen;
            this.btnE12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnE12.FlatAppearance.BorderSize = 0;
            this.btnE12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnE12.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnE12.Location = new System.Drawing.Point(341, 102);
            this.btnE12.Name = "btnE12";
            this.btnE12.Size = new System.Drawing.Size(29, 30);
            this.btnE12.TabIndex = 18;
            this.btnE12.Text = "E2";
            this.btnE12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnE12.UseVisualStyleBackColor = false;
            this.btnE12.Click += new System.EventHandler(this.buttonOnClick);
            this.btnE12.Enter += new System.EventHandler(this.buttonEnter);
            this.btnE12.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnE11
            // 
            this.btnE11.BackColor = System.Drawing.Color.PaleGreen;
            this.btnE11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnE11.FlatAppearance.BorderSize = 0;
            this.btnE11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnE11.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnE11.Location = new System.Drawing.Point(310, 102);
            this.btnE11.Name = "btnE11";
            this.btnE11.Size = new System.Drawing.Size(29, 30);
            this.btnE11.TabIndex = 17;
            this.btnE11.Text = "E1";
            this.btnE11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnE11.UseVisualStyleBackColor = false;
            this.btnE11.Click += new System.EventHandler(this.buttonOnClick);
            this.btnE11.Enter += new System.EventHandler(this.buttonEnter);
            this.btnE11.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnE10
            // 
            this.btnE10.BackColor = System.Drawing.Color.PaleGreen;
            this.btnE10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnE10.FlatAppearance.BorderSize = 0;
            this.btnE10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnE10.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnE10.Location = new System.Drawing.Point(280, 102);
            this.btnE10.Name = "btnE10";
            this.btnE10.Size = new System.Drawing.Size(29, 30);
            this.btnE10.TabIndex = 16;
            this.btnE10.Text = "E0";
            this.btnE10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnE10.UseVisualStyleBackColor = false;
            this.btnE10.Click += new System.EventHandler(this.buttonOnClick);
            this.btnE10.Enter += new System.EventHandler(this.buttonEnter);
            this.btnE10.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnA18
            // 
            this.btnA18.BackColor = System.Drawing.Color.PaleGreen;
            this.btnA18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnA18.FlatAppearance.BorderSize = 0;
            this.btnA18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA18.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnA18.Location = new System.Drawing.Point(521, 302);
            this.btnA18.Name = "btnA18";
            this.btnA18.Size = new System.Drawing.Size(29, 30);
            this.btnA18.TabIndex = 54;
            this.btnA18.Text = "A8";
            this.btnA18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnA18.UseVisualStyleBackColor = false;
            this.btnA18.Click += new System.EventHandler(this.buttonOnClick);
            this.btnA18.Enter += new System.EventHandler(this.buttonEnter);
            this.btnA18.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnA17
            // 
            this.btnA17.BackColor = System.Drawing.Color.PaleGreen;
            this.btnA17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnA17.FlatAppearance.BorderSize = 0;
            this.btnA17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA17.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnA17.Location = new System.Drawing.Point(491, 302);
            this.btnA17.Name = "btnA17";
            this.btnA17.Size = new System.Drawing.Size(29, 30);
            this.btnA17.TabIndex = 53;
            this.btnA17.Text = "A7";
            this.btnA17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnA17.UseVisualStyleBackColor = false;
            this.btnA17.Click += new System.EventHandler(this.buttonOnClick);
            this.btnA17.Enter += new System.EventHandler(this.buttonEnter);
            this.btnA17.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnA16
            // 
            this.btnA16.BackColor = System.Drawing.Color.PaleGreen;
            this.btnA16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnA16.FlatAppearance.BorderSize = 0;
            this.btnA16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA16.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnA16.Location = new System.Drawing.Point(461, 302);
            this.btnA16.Name = "btnA16";
            this.btnA16.Size = new System.Drawing.Size(29, 30);
            this.btnA16.TabIndex = 52;
            this.btnA16.Text = "A6";
            this.btnA16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnA16.UseVisualStyleBackColor = false;
            this.btnA16.Click += new System.EventHandler(this.buttonOnClick);
            this.btnA16.Enter += new System.EventHandler(this.buttonEnter);
            this.btnA16.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnA15
            // 
            this.btnA15.BackColor = System.Drawing.Color.PaleGreen;
            this.btnA15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnA15.FlatAppearance.BorderSize = 0;
            this.btnA15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA15.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnA15.Location = new System.Drawing.Point(431, 302);
            this.btnA15.Name = "btnA15";
            this.btnA15.Size = new System.Drawing.Size(29, 30);
            this.btnA15.TabIndex = 51;
            this.btnA15.Text = "A5";
            this.btnA15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnA15.UseVisualStyleBackColor = false;
            this.btnA15.Click += new System.EventHandler(this.buttonOnClick);
            this.btnA15.Enter += new System.EventHandler(this.buttonEnter);
            this.btnA15.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnA14
            // 
            this.btnA14.BackColor = System.Drawing.Color.PaleGreen;
            this.btnA14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnA14.FlatAppearance.BorderSize = 0;
            this.btnA14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA14.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnA14.Location = new System.Drawing.Point(401, 302);
            this.btnA14.Name = "btnA14";
            this.btnA14.Size = new System.Drawing.Size(29, 30);
            this.btnA14.TabIndex = 50;
            this.btnA14.Text = "A4";
            this.btnA14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnA14.UseVisualStyleBackColor = false;
            this.btnA14.Click += new System.EventHandler(this.buttonOnClick);
            this.btnA14.Enter += new System.EventHandler(this.buttonEnter);
            this.btnA14.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnA13
            // 
            this.btnA13.BackColor = System.Drawing.Color.PaleGreen;
            this.btnA13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnA13.FlatAppearance.BorderSize = 0;
            this.btnA13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA13.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnA13.Location = new System.Drawing.Point(371, 302);
            this.btnA13.Name = "btnA13";
            this.btnA13.Size = new System.Drawing.Size(29, 30);
            this.btnA13.TabIndex = 49;
            this.btnA13.Text = "A3";
            this.btnA13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnA13.UseVisualStyleBackColor = false;
            this.btnA13.Click += new System.EventHandler(this.buttonOnClick);
            this.btnA13.Enter += new System.EventHandler(this.buttonEnter);
            this.btnA13.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnA12
            // 
            this.btnA12.BackColor = System.Drawing.Color.PaleGreen;
            this.btnA12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnA12.FlatAppearance.BorderSize = 0;
            this.btnA12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA12.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnA12.Location = new System.Drawing.Point(341, 302);
            this.btnA12.Name = "btnA12";
            this.btnA12.Size = new System.Drawing.Size(29, 30);
            this.btnA12.TabIndex = 48;
            this.btnA12.Text = "A2";
            this.btnA12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnA12.UseVisualStyleBackColor = false;
            this.btnA12.Click += new System.EventHandler(this.buttonOnClick);
            this.btnA12.Enter += new System.EventHandler(this.buttonEnter);
            this.btnA12.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnA11
            // 
            this.btnA11.BackColor = System.Drawing.Color.PaleGreen;
            this.btnA11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnA11.FlatAppearance.BorderSize = 0;
            this.btnA11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA11.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnA11.Location = new System.Drawing.Point(310, 302);
            this.btnA11.Name = "btnA11";
            this.btnA11.Size = new System.Drawing.Size(29, 30);
            this.btnA11.TabIndex = 47;
            this.btnA11.Text = "A1";
            this.btnA11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnA11.UseVisualStyleBackColor = false;
            this.btnA11.Click += new System.EventHandler(this.buttonOnClick);
            this.btnA11.Enter += new System.EventHandler(this.buttonEnter);
            this.btnA11.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnA10
            // 
            this.btnA10.BackColor = System.Drawing.Color.PaleGreen;
            this.btnA10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnA10.FlatAppearance.BorderSize = 0;
            this.btnA10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnA10.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnA10.Location = new System.Drawing.Point(280, 302);
            this.btnA10.Name = "btnA10";
            this.btnA10.Size = new System.Drawing.Size(29, 30);
            this.btnA10.TabIndex = 46;
            this.btnA10.Text = "A0";
            this.btnA10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnA10.UseVisualStyleBackColor = false;
            this.btnA10.Click += new System.EventHandler(this.buttonOnClick);
            this.btnA10.Enter += new System.EventHandler(this.buttonEnter);
            this.btnA10.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnB18
            // 
            this.btnB18.BackColor = System.Drawing.Color.PaleGreen;
            this.btnB18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnB18.FlatAppearance.BorderSize = 0;
            this.btnB18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnB18.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnB18.Location = new System.Drawing.Point(521, 269);
            this.btnB18.Name = "btnB18";
            this.btnB18.Size = new System.Drawing.Size(29, 30);
            this.btnB18.TabIndex = 42;
            this.btnB18.Text = "B8";
            this.btnB18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnB18.UseVisualStyleBackColor = false;
            this.btnB18.Click += new System.EventHandler(this.buttonOnClick);
            this.btnB18.Enter += new System.EventHandler(this.buttonEnter);
            this.btnB18.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnB17
            // 
            this.btnB17.BackColor = System.Drawing.Color.PaleGreen;
            this.btnB17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnB17.FlatAppearance.BorderSize = 0;
            this.btnB17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnB17.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnB17.Location = new System.Drawing.Point(491, 269);
            this.btnB17.Name = "btnB17";
            this.btnB17.Size = new System.Drawing.Size(29, 30);
            this.btnB17.TabIndex = 41;
            this.btnB17.Text = "B7";
            this.btnB17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnB17.UseVisualStyleBackColor = false;
            this.btnB17.Click += new System.EventHandler(this.buttonOnClick);
            this.btnB17.Enter += new System.EventHandler(this.buttonEnter);
            this.btnB17.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnB16
            // 
            this.btnB16.BackColor = System.Drawing.Color.PaleGreen;
            this.btnB16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnB16.FlatAppearance.BorderSize = 0;
            this.btnB16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnB16.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnB16.Location = new System.Drawing.Point(461, 269);
            this.btnB16.Name = "btnB16";
            this.btnB16.Size = new System.Drawing.Size(29, 30);
            this.btnB16.TabIndex = 40;
            this.btnB16.Text = "B6";
            this.btnB16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnB16.UseVisualStyleBackColor = false;
            this.btnB16.Click += new System.EventHandler(this.buttonOnClick);
            this.btnB16.Enter += new System.EventHandler(this.buttonEnter);
            this.btnB16.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnB15
            // 
            this.btnB15.BackColor = System.Drawing.Color.PaleGreen;
            this.btnB15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnB15.FlatAppearance.BorderSize = 0;
            this.btnB15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnB15.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnB15.Location = new System.Drawing.Point(431, 269);
            this.btnB15.Name = "btnB15";
            this.btnB15.Size = new System.Drawing.Size(29, 30);
            this.btnB15.TabIndex = 39;
            this.btnB15.Text = "B5";
            this.btnB15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnB15.UseVisualStyleBackColor = false;
            this.btnB15.Click += new System.EventHandler(this.buttonOnClick);
            this.btnB15.Enter += new System.EventHandler(this.buttonEnter);
            this.btnB15.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnB14
            // 
            this.btnB14.BackColor = System.Drawing.Color.PaleGreen;
            this.btnB14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnB14.FlatAppearance.BorderSize = 0;
            this.btnB14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnB14.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnB14.Location = new System.Drawing.Point(401, 269);
            this.btnB14.Name = "btnB14";
            this.btnB14.Size = new System.Drawing.Size(29, 30);
            this.btnB14.TabIndex = 38;
            this.btnB14.Text = "B4";
            this.btnB14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnB14.UseVisualStyleBackColor = false;
            this.btnB14.Click += new System.EventHandler(this.buttonOnClick);
            this.btnB14.Enter += new System.EventHandler(this.buttonEnter);
            this.btnB14.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnB13
            // 
            this.btnB13.BackColor = System.Drawing.Color.PaleGreen;
            this.btnB13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnB13.FlatAppearance.BorderSize = 0;
            this.btnB13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnB13.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnB13.Location = new System.Drawing.Point(371, 269);
            this.btnB13.Name = "btnB13";
            this.btnB13.Size = new System.Drawing.Size(29, 30);
            this.btnB13.TabIndex = 37;
            this.btnB13.Text = "B3";
            this.btnB13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnB13.UseVisualStyleBackColor = false;
            this.btnB13.Click += new System.EventHandler(this.buttonOnClick);
            this.btnB13.Enter += new System.EventHandler(this.buttonEnter);
            this.btnB13.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnB12
            // 
            this.btnB12.BackColor = System.Drawing.Color.PaleGreen;
            this.btnB12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnB12.FlatAppearance.BorderSize = 0;
            this.btnB12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnB12.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnB12.Location = new System.Drawing.Point(341, 269);
            this.btnB12.Name = "btnB12";
            this.btnB12.Size = new System.Drawing.Size(29, 30);
            this.btnB12.TabIndex = 36;
            this.btnB12.Text = "B2";
            this.btnB12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnB12.UseVisualStyleBackColor = false;
            this.btnB12.Click += new System.EventHandler(this.buttonOnClick);
            this.btnB12.Enter += new System.EventHandler(this.buttonEnter);
            this.btnB12.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnB11
            // 
            this.btnB11.BackColor = System.Drawing.Color.PaleGreen;
            this.btnB11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnB11.FlatAppearance.BorderSize = 0;
            this.btnB11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnB11.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnB11.Location = new System.Drawing.Point(310, 269);
            this.btnB11.Name = "btnB11";
            this.btnB11.Size = new System.Drawing.Size(29, 30);
            this.btnB11.TabIndex = 35;
            this.btnB11.Text = "B1";
            this.btnB11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnB11.UseVisualStyleBackColor = false;
            this.btnB11.Click += new System.EventHandler(this.buttonOnClick);
            this.btnB11.Enter += new System.EventHandler(this.buttonEnter);
            this.btnB11.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnB10
            // 
            this.btnB10.BackColor = System.Drawing.Color.PaleGreen;
            this.btnB10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnB10.FlatAppearance.BorderSize = 0;
            this.btnB10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnB10.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnB10.Location = new System.Drawing.Point(280, 269);
            this.btnB10.Name = "btnB10";
            this.btnB10.Size = new System.Drawing.Size(29, 30);
            this.btnB10.TabIndex = 34;
            this.btnB10.Text = "B0";
            this.btnB10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnB10.UseVisualStyleBackColor = false;
            this.btnB10.Click += new System.EventHandler(this.buttonOnClick);
            this.btnB10.Enter += new System.EventHandler(this.buttonEnter);
            this.btnB10.Leave += new System.EventHandler(this.buttonLeave);
            // 
            // btnGreen
            // 
            this.btnGreen.BackColor = System.Drawing.Color.PaleGreen;
            this.btnGreen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnGreen.Enabled = false;
            this.btnGreen.FlatAppearance.BorderSize = 0;
            this.btnGreen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGreen.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnGreen.Location = new System.Drawing.Point(355, 415);
            this.btnGreen.Name = "btnGreen";
            this.btnGreen.Size = new System.Drawing.Size(29, 30);
            this.btnGreen.TabIndex = 55;
            this.btnGreen.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGreen.UseVisualStyleBackColor = false;
            // 
            // btnRed
            // 
            this.btnRed.BackColor = System.Drawing.Color.Tomato;
            this.btnRed.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnRed.Enabled = false;
            this.btnRed.FlatAppearance.BorderSize = 0;
            this.btnRed.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRed.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnRed.Location = new System.Drawing.Point(506, 415);
            this.btnRed.Name = "btnRed";
            this.btnRed.Size = new System.Drawing.Size(29, 30);
            this.btnRed.TabIndex = 57;
            this.btnRed.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRed.UseVisualStyleBackColor = false;
            // 
            // lblGreen
            // 
            this.lblGreen.AutoSize = true;
            this.lblGreen.Location = new System.Drawing.Point(390, 422);
            this.lblGreen.Name = "lblGreen";
            this.lblGreen.Size = new System.Drawing.Size(80, 15);
            this.lblGreen.TabIndex = 56;
            this.lblGreen.Text = "Available Seat";
            // 
            // lblRed
            // 
            this.lblRed.AutoSize = true;
            this.lblRed.Location = new System.Drawing.Point(541, 422);
            this.lblRed.Name = "lblRed";
            this.lblRed.Size = new System.Drawing.Size(93, 15);
            this.lblRed.TabIndex = 58;
            this.lblRed.Text = "Unavailable Seat";
            // 
            // btnBlue
            // 
            this.btnBlue.BackColor = System.Drawing.Color.RoyalBlue;
            this.btnBlue.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnBlue.Enabled = false;
            this.btnBlue.FlatAppearance.BorderSize = 0;
            this.btnBlue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBlue.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBlue.Location = new System.Drawing.Point(780, 415);
            this.btnBlue.Name = "btnBlue";
            this.btnBlue.Size = new System.Drawing.Size(29, 30);
            this.btnBlue.TabIndex = 61;
            this.btnBlue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBlue.UseVisualStyleBackColor = false;
            // 
            // lblBlue
            // 
            this.lblBlue.AutoSize = true;
            this.lblBlue.Location = new System.Drawing.Point(815, 422);
            this.lblBlue.Name = "lblBlue";
            this.lblBlue.Size = new System.Drawing.Size(86, 15);
            this.lblBlue.TabIndex = 62;
            this.lblBlue.Text = "Non-Used Seat";
            // 
            // tbxFirstName
            // 
            this.tbxFirstName.Location = new System.Drawing.Point(746, 537);
            this.tbxFirstName.Name = "tbxFirstName";
            this.tbxFirstName.Size = new System.Drawing.Size(189, 23);
            this.tbxFirstName.TabIndex = 65;
            this.tbxFirstName.TextChanged += new System.EventHandler(this.tbxFirstName_TextChanged);
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(676, 540);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(64, 15);
            this.lblFirstName.TabIndex = 64;
            this.lblFirstName.Text = "First Name";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(676, 569);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(63, 15);
            this.lblLastName.TabIndex = 66;
            this.lblLastName.Text = "Last Name";
            // 
            // tbxLastName
            // 
            this.tbxLastName.Location = new System.Drawing.Point(746, 566);
            this.tbxLastName.Name = "tbxLastName";
            this.tbxLastName.Size = new System.Drawing.Size(189, 23);
            this.tbxLastName.TabIndex = 67;
            this.tbxLastName.TextChanged += new System.EventHandler(this.tbxLastName_TextChanged);
            // 
            // lblPostalCode
            // 
            this.lblPostalCode.AutoSize = true;
            this.lblPostalCode.Location = new System.Drawing.Point(669, 597);
            this.lblPostalCode.Name = "lblPostalCode";
            this.lblPostalCode.Size = new System.Drawing.Size(70, 15);
            this.lblPostalCode.TabIndex = 68;
            this.lblPostalCode.Text = "Postal Code";
            // 
            // tbxPostalCode
            // 
            this.tbxPostalCode.Location = new System.Drawing.Point(747, 594);
            this.tbxPostalCode.Name = "tbxPostalCode";
            this.tbxPostalCode.Size = new System.Drawing.Size(189, 23);
            this.tbxPostalCode.TabIndex = 69;
            this.tbxPostalCode.TextChanged += new System.EventHandler(this.tbxPostalCode_TextChanged);
            // 
            // btnReserveSeat
            // 
            this.btnReserveSeat.BackColor = System.Drawing.Color.Chartreuse;
            this.btnReserveSeat.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnReserveSeat.Location = new System.Drawing.Point(669, 623);
            this.btnReserveSeat.Name = "btnReserveSeat";
            this.btnReserveSeat.Size = new System.Drawing.Size(150, 39);
            this.btnReserveSeat.TabIndex = 70;
            this.btnReserveSeat.Text = "Reserve Seat";
            this.btnReserveSeat.UseVisualStyleBackColor = false;
            this.btnReserveSeat.Click += new System.EventHandler(this.btnReserveSeat_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.Red;
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCancel.Location = new System.Drawing.Point(825, 623);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(150, 39);
            this.btnCancel.TabIndex = 71;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lbxReserved
            // 
            this.lbxReserved.FormattingEnabled = true;
            this.lbxReserved.ItemHeight = 15;
            this.lbxReserved.Location = new System.Drawing.Point(19, 477);
            this.lbxReserved.Name = "lbxReserved";
            this.lbxReserved.Size = new System.Drawing.Size(287, 319);
            this.lbxReserved.Sorted = true;
            this.lbxReserved.TabIndex = 0;
            this.lbxReserved.SelectedIndexChanged += new System.EventHandler(this.lbxReserved_SelectedIndexChanged);
            // 
            // lblReserved
            // 
            this.lblReserved.AutoSize = true;
            this.lblReserved.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblReserved.Location = new System.Drawing.Point(87, 454);
            this.lblReserved.Name = "lblReserved";
            this.lblReserved.Size = new System.Drawing.Size(144, 20);
            this.lblReserved.TabIndex = 69;
            this.lblReserved.Text = "Reserved Passengers";
            // 
            // lblYellow
            // 
            this.lblYellow.AutoSize = true;
            this.lblYellow.Location = new System.Drawing.Point(685, 422);
            this.lblYellow.Name = "lblYellow";
            this.lblYellow.Size = new System.Drawing.Size(76, 15);
            this.lblYellow.TabIndex = 63;
            this.lblYellow.Text = "Selected Seat";
            // 
            // btnYellow
            // 
            this.btnYellow.BackColor = System.Drawing.Color.Yellow;
            this.btnYellow.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnYellow.Enabled = false;
            this.btnYellow.FlatAppearance.BorderSize = 0;
            this.btnYellow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnYellow.Font = new System.Drawing.Font("Centaur", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnYellow.Location = new System.Drawing.Point(650, 415);
            this.btnYellow.Name = "btnYellow";
            this.btnYellow.Size = new System.Drawing.Size(29, 30);
            this.btnYellow.TabIndex = 59;
            this.btnYellow.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnYellow.UseVisualStyleBackColor = false;
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.Chartreuse;
            this.btnUpdate.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnUpdate.Location = new System.Drawing.Point(669, 623);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(150, 39);
            this.btnUpdate.TabIndex = 72;
            this.btnUpdate.Text = "Update Seat";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnCancelSeat
            // 
            this.btnCancelSeat.BackColor = System.Drawing.Color.Red;
            this.btnCancelSeat.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnCancelSeat.Location = new System.Drawing.Point(825, 623);
            this.btnCancelSeat.Name = "btnCancelSeat";
            this.btnCancelSeat.Size = new System.Drawing.Size(150, 39);
            this.btnCancelSeat.TabIndex = 73;
            this.btnCancelSeat.Text = "Cancel Seat";
            this.btnCancelSeat.UseVisualStyleBackColor = false;
            this.btnCancelSeat.Click += new System.EventHandler(this.btnCancelSeat_Click);
            // 
            // err1
            // 
            this.err1.BlinkRate = 1;
            this.err1.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.err1.ContainerControl = this;
            // 
            // PlaneSeatReservation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CausesValidation = false;
            this.ClientSize = new System.Drawing.Size(1265, 815);
            this.Controls.Add(this.btnCancelSeat);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.lblYellow);
            this.Controls.Add(this.btnYellow);
            this.Controls.Add(this.lblReserved);
            this.Controls.Add(this.lbxReserved);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnReserveSeat);
            this.Controls.Add(this.lblPostalCode);
            this.Controls.Add(this.tbxPostalCode);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.tbxLastName);
            this.Controls.Add(this.lblFirstName);
            this.Controls.Add(this.tbxFirstName);
            this.Controls.Add(this.lblBlue);
            this.Controls.Add(this.btnBlue);
            this.Controls.Add(this.lblRed);
            this.Controls.Add(this.lblGreen);
            this.Controls.Add(this.btnRed);
            this.Controls.Add(this.btnGreen);
            this.Controls.Add(this.btnA18);
            this.Controls.Add(this.btnA17);
            this.Controls.Add(this.btnA16);
            this.Controls.Add(this.btnA15);
            this.Controls.Add(this.btnA14);
            this.Controls.Add(this.btnA13);
            this.Controls.Add(this.btnA12);
            this.Controls.Add(this.btnA11);
            this.Controls.Add(this.btnA10);
            this.Controls.Add(this.btnB18);
            this.Controls.Add(this.btnB17);
            this.Controls.Add(this.btnB16);
            this.Controls.Add(this.btnB15);
            this.Controls.Add(this.btnB14);
            this.Controls.Add(this.btnB13);
            this.Controls.Add(this.btnB12);
            this.Controls.Add(this.btnB11);
            this.Controls.Add(this.btnB10);
            this.Controls.Add(this.btnE18);
            this.Controls.Add(this.btnE17);
            this.Controls.Add(this.btnE16);
            this.Controls.Add(this.btnE15);
            this.Controls.Add(this.btnE14);
            this.Controls.Add(this.btnE13);
            this.Controls.Add(this.btnE12);
            this.Controls.Add(this.btnE11);
            this.Controls.Add(this.btnE10);
            this.Controls.Add(this.btnF18);
            this.Controls.Add(this.btnF17);
            this.Controls.Add(this.btnF16);
            this.Controls.Add(this.btnF15);
            this.Controls.Add(this.btnF14);
            this.Controls.Add(this.btnF13);
            this.Controls.Add(this.btnF12);
            this.Controls.Add(this.btnF11);
            this.Controls.Add(this.btnF10);
            this.Controls.Add(this.btnD3);
            this.Controls.Add(this.btnD2);
            this.Controls.Add(this.btnD1);
            this.Controls.Add(this.btnC3);
            this.Controls.Add(this.btnC2);
            this.Controls.Add(this.btnC1);
            this.Controls.Add(this.btnB3);
            this.Controls.Add(this.btnB2);
            this.Controls.Add(this.btnB1);
            this.Controls.Add(this.btnA3);
            this.Controls.Add(this.btnA2);
            this.Controls.Add(this.btnA1);
            this.Controls.Add(this.btnE3);
            this.Controls.Add(this.btnE2);
            this.Controls.Add(this.btnE1);
            this.Controls.Add(this.btnF3);
            this.Controls.Add(this.btnF2);
            this.Controls.Add(this.btnF1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "PlaneSeatReservation";
            this.Text = "Plane Seat Reservation";
            this.Load += new System.EventHandler(this.PlaneSeatReservation_Load);
            this.Enter += new System.EventHandler(this.PlaneSeatReservation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.err1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox pictureBox1;
        private Button btnF1;
        private Button btnF2;
        private Button btnF3;
        private Button btnE3;
        private Button btnE2;
        private Button btnE1;
        private Button btnA3;
        private Button btnA2;
        private Button btnA1;
        private Button btnB3;
        private Button btnB2;
        private Button btnB1;
        private Button btnC3;
        private Button btnC2;
        private Button btnC1;
        private Button btnD3;
        private Button btnD2;
        private Button btnD1;
        private Button btnF12;
        private Button btnF11;
        private Button btnF10;
        private Button btnF15;
        private Button btnF14;
        private Button btnF13;
        private Button btnF18;
        private Button button14;
        private Button button15;
        private Button btnE18;
        private Button btnE17;
        private Button btnE16;
        private Button btnE15;
        private Button btnE14;
        private Button btnE13;
        private Button btnE12;
        private Button btnE11;
        private Button btnE10;
        private Button btnA18;
        private Button btnA17;
        private Button btnA16;
        private Button btnA15;
        private Button btnA14;
        private Button btnA13;
        private Button btnA12;
        private Button btnA11;
        private Button btnA10;
        private Button btnB18;
        private Button btnB17;
        private Button btnB16;
        private Button button37;
        private Button button38;
        private Button btnB13;
        private Button btnB12;
        private Button btnB11;
        private Button btnB10;
        private Button btnGreen;
        private Button btnRed;
        private Label lblGreen;
        private Label lblRed;
        private Button btnBlue;
        private Label lblBlue;
        private TextBox tbxFirstName;
        private Label lblFirstName;
        private Label lblLastName;
        private TextBox tbxLastName;
        private Label lblPostalCode;
        private TextBox tbxPostalCode;
        private Button btnReserveSeat;
        private Button btnCancel;
        private ListBox lbxReserved;
        private Label lblReserved;
        private Button btnF17;
        private Button btnF16;
        private Button btnB15;
        private Button btnB14;
        private Label lblYellow;
        private Button btnYellow;
        private Button btnUpdate;
        private Button btnCancelSeat;
        private ErrorProvider err1;
    }
}