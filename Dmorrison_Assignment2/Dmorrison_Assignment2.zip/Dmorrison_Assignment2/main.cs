﻿/**
 * @file         main.cs
 * @author	     Darren Morrison
 * @date         2022-09-27
 * @brief        User Interface Assignment 2
 * @details      Creates Game object.
 */

Console.Title = "Tic Tac Toe";
Game TicTacToe = new Game();

